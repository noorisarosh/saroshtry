import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, ArrowLeft, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useFavorites } from "@/hooks/use-favorites";
import { CourseReviews } from "@/components/CourseReviews";

interface CourseDetail {
  id: number;
  code: string | null;
  name: string | null;
  credit: number | null;
  dept: string;
  desc: string | null;
  prereqs: string | null;
}

const CourseDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [course, setCourse] = useState<CourseDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { isFavorite, toggleFavorite } = useFavorites();

  useEffect(() => {
    fetchCourse();
  }, [id]);

  const fetchCourse = async () => {
    try {
      const { data, error } = await supabase
        .from("course")
        .select("*")
        .eq("id", Number(id))
        .maybeSingle();

      if (error) throw error;

      setCourse(data);
    } catch (error) {
      console.error("Error fetching course:", error);
      toast({
        title: "Error",
        description: "Failed to load course details.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-background">
        <header className="bg-primary text-primary-foreground shadow-sm">
          <div className="max-w-2xl mx-auto px-4 py-6">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/")}
              className="text-primary-foreground hover:bg-primary-foreground/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </div>
        </header>
        <div className="max-w-2xl mx-auto px-4 py-12 text-center">
          <p className="text-muted-foreground">Course not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground shadow-sm">
        <div className="max-w-2xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/")}
              className="text-primary-foreground hover:bg-primary-foreground/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => toggleFavorite(course.id)}
              className="text-primary-foreground hover:bg-primary-foreground/10"
            >
              <Heart
                className={`h-5 w-5 ${
                  isFavorite(course.id)
                    ? "fill-primary-foreground"
                    : ""
                }`}
              />
            </Button>
          </div>
          <h1 className="text-2xl font-bold">{course.code}</h1>
          <p className="text-sm text-primary-foreground/80 mt-1">
            Course Details
          </p>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6 space-y-6 pb-20">
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-start justify-between gap-3">
              <CardTitle className="text-2xl">{course.name}</CardTitle>
              <div className="bg-primary/10 text-primary font-semibold text-sm px-3 py-1.5 rounded-full">
                {course.credit} CR
              </div>
            </div>
            <Badge variant="secondary" className="w-fit mt-2">
              {course.dept}
            </Badge>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold text-foreground mb-2">Description</h3>
              <p className="text-muted-foreground">
                {course.desc || "No description available"}
              </p>
            </div>
            
            {course.prereqs && (
              <div>
                <h3 className="font-semibold text-foreground mb-2">Prerequisites</h3>
                <p className="text-muted-foreground">{course.prereqs}</p>
              </div>
            )}
          </CardContent>
        </Card>

        <CourseReviews courseId={course.id} />
      </main>
    </div>
  );
};

export default CourseDetail;
