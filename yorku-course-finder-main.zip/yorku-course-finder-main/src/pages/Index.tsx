import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { SearchBar } from "@/components/SearchBar";
import { CourseCard } from "@/components/CourseCard";
import { BottomNav } from "@/components/BottomNav";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, ArrowLeft, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useFavorites } from "@/hooks/use-favorites";

interface Course {
  id: number;
  code: string | null;
  name: string | null;
  credit: number | null;
  dept: string;
}

const Index = () => {
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { isFavorite, toggleFavorite } = useFavorites();
  const navigate = useNavigate();

  const levels = ["1000", "2000", "3000", "4000", "5000", "6000", "7000"];

  useEffect(() => {
    if (searchQuery.trim().length >= 2) {
      searchCourses(searchQuery);
    } else {
      setCourses([]);
    }
  }, [searchQuery, selectedLevel]);

  const searchCourses = async (query: string) => {
    setLoading(true);
    try {
      const searchTerm = query.trim().toLowerCase();
      
      // Check if search contains both dept and code (e.g., "math 1532" or "eecs2030")
      const deptCodeMatch = searchTerm.match(/^([a-z]+)\s*(\d+)$/);
      
      let supabaseQuery = supabase
        .from("course")
        .select("id, code, name, credit, dept");
      
      if (deptCodeMatch) {
        // If it's dept + code format, search for exact dept and code that contains the number
        const [, dept, code] = deptCodeMatch;
        supabaseQuery = supabaseQuery
          .or(`and(dept.ilike.${dept},code.ilike.%${code}%),code.ilike.%${searchTerm}%,name.ilike.%${searchTerm}%`);
      } else {
        // Otherwise use regular OR search
        supabaseQuery = supabaseQuery
          .or(`code.ilike.%${searchTerm}%,dept.ilike.%${searchTerm}%,name.ilike.%${searchTerm}%`);
      }
      
      const { data, error } = await supabaseQuery
        .order("code", { ascending: true })
        .limit(500);

      if (error) throw error;

      let filteredData = data || [];
      
      // Filter by level if selected
      if (selectedLevel) {
        filteredData = filteredData.filter(course => {
          if (!course.code) return false;
          const match = course.code.match(/(\d+)/);
          if (!match) return false;
          const firstDigit = match[1][0];
          const levelFirstDigit = selectedLevel[0];
          return firstDigit === levelFirstDigit;
        });
      }

      setCourses(filteredData);
    } catch (error) {
      console.error("Error searching courses:", error);
      toast({
        title: "Error",
        description: "Failed to search courses. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (!showSearch) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <header className="bg-primary text-primary-foreground shadow-sm">
          <div className="max-w-2xl mx-auto px-4 py-6">
            <h1 className="text-2xl font-bold">YorkUFind</h1>
            <p className="text-sm text-primary-foreground/80 mt-1">
              Find what you're looking for
            </p>
          </div>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-8">
          <div className="space-y-4">
            <button
              onClick={() => setShowSearch(true)}
              className="w-full p-6 bg-card border border-border rounded-lg hover:bg-accent transition-colors text-left"
            >
              <h2 className="text-lg font-semibold text-foreground mb-1">Search Courses</h2>
              <p className="text-sm text-muted-foreground">
                Find York University courses by code or subject
              </p>
            </button>
          </div>
        </main>

        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-primary text-primary-foreground shadow-sm">
        <div className="max-w-2xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3 mb-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowSearch(false)}
              className="text-primary-foreground hover:bg-primary-foreground/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-2xl font-bold">YorkUFind</h1>
          </div>
          <p className="text-sm text-primary-foreground/80 ml-12">
            Search York University courses
          </p>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6">
        <div className="mb-6">
          <SearchBar
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Search by course code or subject (e.g., EECS, CSE1001)"
          />
        </div>

        <div className="mb-4 flex flex-wrap gap-2">
          <span className="text-sm text-muted-foreground self-center">Level:</span>
          <Badge
            variant={selectedLevel === null ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setSelectedLevel(null)}
          >
            All
          </Badge>
          {levels.map((level) => (
            <Badge
              key={level}
              variant={selectedLevel === level ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setSelectedLevel(level)}
            >
              {level}
            </Badge>
          ))}
        </div>

        <div className="space-y-3">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : searchQuery.trim().length < 2 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>Enter at least 2 characters to search</p>
            </div>
          ) : courses.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>No courses found</p>
            </div>
          ) : (
            <>
              <p className="text-sm text-muted-foreground mb-4">
                Found {courses.length} course{courses.length !== 1 ? "s" : ""}
              </p>
              {courses.map((course) => (
                <div
                  key={course.id}
                  className="relative"
                >
                  <div
                    onClick={() => navigate(`/course/${course.id}`)}
                    className="cursor-pointer"
                  >
                    <CourseCard
                      code={course.code || "N/A"}
                      name={course.name || "No name available"}
                      credit={course.credit || 0}
                      dept={course.dept}
                    />
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(course.id);
                    }}
                  >
                    <Heart
                      className={`h-5 w-5 ${
                        isFavorite(course.id)
                          ? "fill-primary text-primary"
                          : "text-muted-foreground"
                      }`}
                    />
                  </Button>
                </div>
              ))}
            </>
          )}
        </div>
      </main>

      <BottomNav />
    </div>
  );
};

export default Index;
