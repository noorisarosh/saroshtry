import { useTheme } from "next-themes";
import { BottomNav } from "@/components/BottomNav";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Moon, Sun, Mail } from "lucide-react";

const Settings = () => {
  const { theme, setTheme } = useTheme();

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-primary text-primary-foreground shadow-sm">
        <div className="max-w-2xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Settings</h1>
          <p className="text-sm text-primary-foreground/80 mt-1">
            Customize your experience
          </p>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
            <CardDescription>Customize how the app looks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {theme === "dark" ? (
                  <Moon className="h-5 w-5 text-muted-foreground" />
                ) : (
                  <Sun className="h-5 w-5 text-muted-foreground" />
                )}
                <Label htmlFor="dark-mode" className="text-base cursor-pointer">
                  Dark Mode
                </Label>
              </div>
              <Switch
                id="dark-mode"
                checked={theme === "dark"}
                onCheckedChange={(checked) => setTheme(checked ? "dark" : "light")}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle>About YorkUFind</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              YorkUFind is an independent student project developed by a York University student with the goal of helping students.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              While every effort has been made to ensure accuracy and smooth performance, occasional issues or bugs may occur, please be patient and understanding as the app continues to improve.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Thank you for using YorkUFind and supporting student-built projects! Your feedback and encouragement help make this app better with every update.
            </p>
            
            <div className="pt-2 border-t border-border">
              <p className="text-sm font-medium mb-3">Have feedback or found a bug?</p>
              <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                Your input is invaluable! Whether you've encountered an issue, have a suggestion for improvement, or just want to share your experience, I'd love to hear from you. Every piece of feedback helps make YorkUFind better for everyone.
              </p>
              <Button 
                variant="outline" 
                className="w-full"
                disabled
              >
                <Mail className="mr-2 h-4 w-4" />
                Contact Developer (Coming Soon)
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      <BottomNav />
    </div>
  );
};

export default Settings;
