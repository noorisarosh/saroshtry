import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { CourseCard } from "@/components/CourseCard";
import { BottomNav } from "@/components/BottomNav";
import { useFavorites } from "@/hooks/use-favorites";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

interface Course {
  id: number;
  code: string | null;
  name: string | null;
  credit: number | null;
  dept: string;
}

const Favorites = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const { favorites } = useFavorites();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadFavorites();
  }, [favorites]);

  const loadFavorites = async () => {
    if (favorites.length === 0) {
      setCourses([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("course")
        .select("id, code, name, credit, dept")
        .in("id", favorites);

      if (error) throw error;

      setCourses(data || []);
    } catch (error) {
      console.error("Error loading favorites:", error);
      toast({
        title: "Error",
        description: "Failed to load favorites. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-primary text-primary-foreground shadow-sm">
        <div className="max-w-2xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Favorites</h1>
          <p className="text-sm text-primary-foreground/80 mt-1">
            Your saved courses
          </p>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : courses.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <p>No favorite courses yet</p>
            <p className="text-sm mt-2">Add courses to your favorites from search</p>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground mb-4">
              {courses.length} favorite course{courses.length !== 1 ? "s" : ""}
            </p>
            {courses.map((course) => (
              <div
                key={course.id}
                onClick={() => navigate(`/course/${course.id}`)}
                className="cursor-pointer"
              >
                <CourseCard
                  code={course.code || "N/A"}
                  name={course.name || "No name available"}
                  credit={course.credit || 0}
                  dept={course.dept}
                />
              </div>
            ))}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default Favorites;
