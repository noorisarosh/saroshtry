import { useState, useEffect } from "react";

const FAVORITES_KEY = "yorkufind_favorites";

export const useFavorites = () => {
  const [favorites, setFavorites] = useState<number[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem(FAVORITES_KEY);
    if (stored) {
      setFavorites(JSON.parse(stored));
    }
  }, []);

  const addFavorite = (courseId: number) => {
    const updated = [...favorites, courseId];
    setFavorites(updated);
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
  };

  const removeFavorite = (courseId: number) => {
    const updated = favorites.filter(id => id !== courseId);
    setFavorites(updated);
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
  };

  const isFavorite = (courseId: number) => {
    return favorites.includes(courseId);
  };

  const toggleFavorite = (courseId: number) => {
    if (isFavorite(courseId)) {
      removeFavorite(courseId);
    } else {
      addFavorite(courseId);
    }
  };

  return {
    favorites,
    addFavorite,
    removeFavorite,
    isFavorite,
    toggleFavorite,
  };
};
