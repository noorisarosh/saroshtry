import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface CourseCardProps {
  code: string;
  name: string;
  credit: number;
  dept: string;
}

export const CourseCard = ({ code, name, credit, dept }: CourseCardProps) => {
  return (
    <Card className="p-4 hover:shadow-md transition-shadow bg-card border-border">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-lg text-foreground mb-1 truncate">
            {code}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
            {name}
          </p>
          <div className="flex gap-2 flex-wrap">
            <Badge variant="secondary" className="text-xs">
              {dept}
            </Badge>
          </div>
        </div>
        <div className="flex-shrink-0">
          <div className="bg-primary/10 text-primary font-semibold text-sm px-3 py-1.5 rounded-full">
            {credit} CR
          </div>
        </div>
      </div>
    </Card>
  );
};
