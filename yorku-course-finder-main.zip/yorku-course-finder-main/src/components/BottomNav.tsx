import { Home, Settings, Heart } from "lucide-react";
import { NavLink } from "./NavLink";

export const BottomNav = () => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border shadow-lg">
      <div className="max-w-2xl mx-auto flex items-center justify-around py-3 px-4">
        <NavLink
          to="/"
          className="flex flex-col items-center gap-1 py-2 px-4 rounded-lg transition-colors text-muted-foreground"
          activeClassName="!text-primary bg-primary/10"
        >
          <Home className="h-6 w-6" />
          <span className="text-xs font-medium">Home</span>
        </NavLink>
        
        <NavLink
          to="/favorites"
          className="flex flex-col items-center gap-1 py-2 px-4 rounded-lg transition-colors text-muted-foreground"
          activeClassName="!text-primary bg-primary/10"
        >
          <Heart className="h-6 w-6" />
          <span className="text-xs font-medium">Favorites</span>
        </NavLink>
        
        <NavLink
          to="/settings"
          className="flex flex-col items-center gap-1 py-2 px-4 rounded-lg transition-colors text-muted-foreground"
          activeClassName="!text-primary bg-primary/10"
        >
          <Settings className="h-6 w-6" />
          <span className="text-xs font-medium">Settings</span>
        </NavLink>
      </div>
    </nav>
  );
};
