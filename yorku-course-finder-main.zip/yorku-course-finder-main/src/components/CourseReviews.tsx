import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";

interface CourseReviewsProps {
  courseId: number;
}

interface Review {
  id: string;
  rating: number;
  created_at: string;
}

export const CourseReviews = ({ courseId }: CourseReviewsProps) => {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [hasReviewed, setHasReviewed] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    const reviewedCourses = JSON.parse(localStorage.getItem("reviewedCourses") || "[]");
    setHasReviewed(reviewedCourses.includes(courseId));
  }, [courseId]);

  const { data: reviews = [], isLoading } = useQuery({
    queryKey: ["reviews", courseId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reviews")
        .select("*")
        .eq("course_id", courseId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as Review[];
    },
  });

  const submitReview = useMutation({
    mutationFn: async () => {
      if (rating === 0) {
        throw new Error("Please select a rating");
      }

      if (hasReviewed) {
        throw new Error("You have already reviewed this course");
      }

      const { error } = await supabase.from("reviews").insert({
        course_id: courseId,
        rating,
      });

      if (error) throw error;
    },
    onSuccess: () => {
      const reviewedCourses = JSON.parse(localStorage.getItem("reviewedCourses") || "[]");
      reviewedCourses.push(courseId);
      localStorage.setItem("reviewedCourses", JSON.stringify(reviewedCourses));
      
      queryClient.invalidateQueries({ queryKey: ["reviews", courseId] });
      setRating(0);
      setHasReviewed(true);
      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const averageRating = reviews.length > 0
    ? reviews.reduce((acc, review) => acc + review.rating, 0) / reviews.length
    : 0;

  const renderStars = (currentRating: number, interactive = false, onHover?: (rating: number) => void, onClick?: (rating: number) => void) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-5 w-5 ${interactive ? 'cursor-pointer' : ''} ${
              star <= currentRating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"
            }`}
            onMouseEnter={() => interactive && onHover?.(star)}
            onMouseLeave={() => interactive && onHover?.(0)}
            onClick={() => interactive && onClick?.(star)}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Course Reviews</CardTitle>
          <CardDescription>
            {reviews.length > 0 ? (
              <div className="flex items-center gap-2 mt-2">
                <span className="text-2xl font-bold text-foreground">
                  {averageRating.toFixed(1)}
                </span>
                {renderStars(Math.round(averageRating))}
                <span className="text-sm text-muted-foreground">
                  ({reviews.length} {reviews.length === 1 ? "review" : "reviews"})
                </span>
              </div>
            ) : (
              <span className="text-muted-foreground">No reviews yet. Be the first to review!</span>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {hasReviewed ? (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">
                You have already reviewed this course. Thank you for your feedback!
              </p>
            </div>
          ) : (
            <>
              <div>
                <label className="text-sm font-medium mb-2 block">Your Rating</label>
                {renderStars(
                  hoveredRating || rating,
                  true,
                  setHoveredRating,
                  setRating
                )}
              </div>

              <Button
                onClick={() => submitReview.mutate()}
                disabled={rating === 0 || submitReview.isPending}
                className="w-full"
              >
                {submitReview.isPending ? "Submitting..." : "Submit Rating"}
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      {isLoading ? (
        <p className="text-center text-muted-foreground">Loading ratings...</p>
      ) : reviews.length > 0 ? (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">All Ratings</h3>
          {reviews.map((review) => (
            <Card key={review.id} className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  {renderStars(review.rating)}
                  <span className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(review.created_at), { addSuffix: true })}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : null}
    </div>
  );
};
