-- Create reviews table for course ratings and reviews
CREATE TABLE public.reviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  course_id BIGINT NOT NULL REFERENCES public.course(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_text TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for faster queries by course_id
CREATE INDEX idx_reviews_course_id ON public.reviews(course_id);

-- Create index for sorting by date
CREATE INDEX idx_reviews_created_at ON public.reviews(created_at DESC);

-- Enable Row Level Security
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- Allow everyone to read reviews
CREATE POLICY "Allow read access to all reviews for anon users"
ON public.reviews
FOR SELECT
USING (true);

-- Allow anyone to submit reviews (anonymous)
CREATE POLICY "Allow anonymous users to insert reviews"
ON public.reviews
FOR INSERT
WITH CHECK (true);